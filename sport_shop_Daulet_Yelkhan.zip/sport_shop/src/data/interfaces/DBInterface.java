package data.interfaces;

import java.sql.Connection;
public interface DBInterface {
    public Connection getConnection();
}